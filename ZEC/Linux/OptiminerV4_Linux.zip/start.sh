./silentarmy --use 0,1,2,3,4,5,6 -c stratum+tcp://zec.waterhole.xyz:3329 -u t1PVXAgAoikskok6wQiT9zTGacZR5mPpyJ1.YourWorker -p x
